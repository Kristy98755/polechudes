from __future__ import annotations

import tkinter as tk
from tkinter import ttk

from app.model import GameState, Puzzle


PHRASES = [
    "Крутите барабан!",
    "Есть такая буква!",
    "Нет такой буквы!",
    "Банкрот!",
    "Приз в студию!",
    "Сектор ПРИЗ!",
    "Переход хода!",
]


class ControlWindow:
    def __init__(self, root: tk.Tk, state: GameState, game_window) -> None:
        self.state = state
        self.game_window = game_window

        self.window = tk.Toplevel(root)
        self.window.title("Поле чудес — Управление")
        self.window.configure(bg="#05070a")
        self.window.minsize(860, 700)

        self._log_visible = tk.BooleanVar(value=True)

        self._build()
        self.state.subscribe_log(self._on_log)

        self._refresh_puzzles_list()
        self._refresh_scores_panel()

    def _build(self) -> None:
        root = self.window
        top = tk.Frame(root, bg="#05070a")
        top.pack(fill="x", padx=12, pady=10)

        title = tk.Label(
            top,
            text="CONTROL PANEL",
            font=("Consolas", 22, "bold"),
            fg="#61ff7a",
            bg="#05070a",
        )
        title.pack(side="left")

        btns = tk.Frame(top, bg="#05070a")
        btns.pack(side="right")

        tk.Button(
            btns,
            text="ЭКСТРЕННО СТОП",
            font=("Consolas", 12, "bold"),
            bg="#2a0000",
            fg="#ff5f5f",
            activebackground="#3a0000",
            activeforeground="#ffffff",
            relief="flat",
            command=self.on_emergency_stop,
        ).pack(side="right", padx=(8, 0))

        tk.Button(
            btns,
            text="КРУТИТЬ",
            font=("Consolas", 12, "bold"),
            bg="#06240d",
            fg="#61ff7a",
            activebackground="#093715",
            activeforeground="#b8ffbf",
            relief="flat",
            command=self.on_spin,
        ).pack(side="right", padx=(8, 0))

        main = tk.Frame(root, bg="#05070a")
        main.pack(fill="both", expand=True, padx=12, pady=(0, 12))

        left = tk.Frame(main, bg="#05070a")
        left.pack(side="left", fill="both", expand=True)

        right = tk.Frame(main, bg="#05070a")
        right.pack(side="right", fill="y", padx=(12, 0))

        # ---- puzzle editor ----
        puz = ttk.LabelFrame(left, text="Вопросы / слова")
        puz.pack(fill="x")

        self.q_var = tk.StringVar()
        self.a_var = tk.StringVar()
        self.e_var = tk.StringVar()

        form = tk.Frame(puz)
        form.pack(fill="x", padx=10, pady=10)

        _row(form, 0, "Вопрос:", self.q_var)
        _row(form, 1, "Ответ:", self.a_var)
        _row(form, 2, "Объяснение:", self.e_var)

        row_btn = tk.Frame(form)
        row_btn.grid(row=3, column=1, sticky="w", pady=(10, 0))

        ttk.Button(row_btn, text="Добавить (обычный тур)", command=self.on_add_regular).pack(side="left")
        ttk.Button(row_btn, text="Добавить (финал)", command=self.on_add_final).pack(side="left", padx=6)
        ttk.Button(row_btn, text="Добавить (супер)", command=self.on_add_super).pack(side="left")

        quick = tk.Frame(puz)
        quick.pack(fill="x", padx=10, pady=(0, 10))

        self.quick_word_var = tk.StringVar()
        ttk.Label(quick, text="Быстро добавить слово:").pack(side="left")
        ttk.Entry(quick, textvariable=self.quick_word_var, width=28).pack(side="left", padx=6)
        ttk.Button(quick, text="Добавить", command=self.on_add_word_quick).pack(side="left")

        # list
        lst = tk.Frame(puz)
        lst.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.puzzles_list = tk.Listbox(lst, height=7)
        self.puzzles_list.pack(side="left", fill="both", expand=True)
        self.puzzles_list.bind("<<ListboxSelect>>", self.on_select_puzzle)

        sc = ttk.Scrollbar(lst, orient="vertical", command=self.puzzles_list.yview)
        sc.pack(side="right", fill="y")
        self.puzzles_list.configure(yscrollcommand=sc.set)

        # ---- phrases ----
        ph = ttk.LabelFrame(left, text="Реплики (вне очереди)")
        ph.pack(fill="x", pady=(10, 0))
        ph_in = tk.Frame(ph)
        ph_in.pack(fill="x", padx=10, pady=10)

        self.phrase_var = tk.StringVar(value=PHRASES[0])
        ttk.OptionMenu(ph_in, self.phrase_var, self.phrase_var.get(), *PHRASES).pack(side="left")
        ttk.Button(ph_in, text="Проиграть", command=self.on_play_phrase).pack(side="left", padx=8)

        # ---- players/scores ----
        pl = ttk.LabelFrame(right, text="Текущая тройка")
        pl.pack(fill="x")

        self.name_vars = [tk.StringVar(), tk.StringVar(), tk.StringVar()]
        self.score_vars = [tk.StringVar(), tk.StringVar(), tk.StringVar()]

        for i in range(3):
            fr = tk.Frame(pl)
            fr.pack(fill="x", padx=10, pady=(10 if i == 0 else 6, 0))

            ttk.Label(fr, text=f"Игрок {i + 1} имя:").grid(row=0, column=0, sticky="w")
            ttk.Entry(fr, textvariable=self.name_vars[i], width=18).grid(row=0, column=1, sticky="w", padx=6)
            ttk.Button(fr, text="Применить", command=lambda ix=i: self.on_set_name(ix)).grid(row=0, column=2, sticky="w")

            ttk.Label(fr, text="Очки:").grid(row=1, column=0, sticky="w", pady=(4, 0))
            ttk.Entry(fr, textvariable=self.score_vars[i], width=10).grid(row=1, column=1, sticky="w", padx=6, pady=(4, 0))
            ttk.Button(fr, text="Установить", command=lambda ix=i: self.on_set_score(ix)).grid(row=1, column=2, sticky="w", pady=(4, 0))

        nav = tk.Frame(pl)
        nav.pack(fill="x", padx=10, pady=10)
        ttk.Button(nav, text="Следующая тройка (сброс сцены)", command=self.on_next_trio).pack(fill="x")

        # ---- history ----
        hist = ttk.LabelFrame(right, text="История троек (на пульте)")
        hist.pack(fill="both", expand=True, pady=(10, 0))

        self.hist_text = tk.Text(hist, height=10, width=32, bg="#06090f", fg="#b9ffbf", insertbackground="#61ff7a")
        self.hist_text.pack(fill="both", expand=True, padx=8, pady=8)
        self.hist_text.configure(state="disabled")

        # ---- log terminal ----
        logf = ttk.LabelFrame(left, text="Лог (терминал)")
        logf.pack(fill="both", expand=True, pady=(10, 0))

        log_top = tk.Frame(logf)
        log_top.pack(fill="x", padx=10, pady=(10, 0))

        ttk.Checkbutton(log_top, text="Показывать лог", variable=self._log_visible, command=self._toggle_log).pack(side="left")
        ttk.Button(log_top, text="Очистить", command=self._clear_log).pack(side="right")

        self.log_text = tk.Text(
            logf,
            height=12,
            bg="#000000",
            fg="#61ff7a",
            insertbackground="#61ff7a",
            font=("Consolas", 10),
        )
        self.log_text.pack(fill="both", expand=True, padx=10, pady=10)
        self.log_text.insert("end", "[BOOT] Control panel online\n")
        self.log_text.configure(state="disabled")

    # -------------------- actions --------------------
    def on_spin(self) -> None:
        self.state.log("Команда: крутить барабан")

        def _stopped(sector):
            self.state.log(f"Барабан остановился: {sector.label}")

        self.game_window.start_spin(on_stop=_stopped)

    def on_emergency_stop(self) -> None:
        self.state.log("Команда: ЭКСТРЕННО ОСТАНОВИТЬ")
        try:
            sector = self.game_window.emergency_stop()
            self.state.log(f"Экстренная остановка: {sector.label}")
        except Exception as e:
            self.state.log(f"Экстренная остановка: ошибка: {e}")

    def on_play_phrase(self) -> None:
        self.state.play_phrase(self.phrase_var.get())

    def on_add_regular(self) -> None:
        self._add_puzzle(category="regular")

    def on_add_final(self) -> None:
        self._add_puzzle(category="final")

    def on_add_super(self) -> None:
        self._add_puzzle(category="super")

    def _add_puzzle(self, category: str) -> None:
        q = self.q_var.get().strip() or "(без вопроса)"
        a = self.a_var.get().strip()
        if not a:
            self.state.log("Ответ пустой — не добавляю.")
            return
        e = self.e_var.get().strip()
        self.state.add_puzzle(Puzzle(question=q, answer=a, explanation=e, category=category))  # type: ignore[arg-type]
        self.q_var.set("")
        self.a_var.set("")
        self.e_var.set("")
        self._refresh_puzzles_list()
        self.game_window.refresh_from_state()

    def on_add_word_quick(self) -> None:
        w = self.quick_word_var.get().strip()
        if not w:
            return
        self.state.add_word_quick(w)
        self.quick_word_var.set("")
        self._refresh_puzzles_list()
        self.game_window.refresh_from_state()

    def on_select_puzzle(self, _evt=None) -> None:
        sel = self.puzzles_list.curselection()
        if not sel:
            return
        idx = int(sel[0])
        try:
            self.state.set_current_puzzle(idx)
        except Exception as e:
            self.state.log(f"Выбор вопроса: ошибка: {e}")
        self.game_window.refresh_from_state()

    def on_set_name(self, idx: int) -> None:
        self.state.set_player_name(idx, self.name_vars[idx].get())
        self.game_window.refresh_from_state()
        self._refresh_scores_panel()

    def on_set_score(self, idx: int) -> None:
        try:
            val = int(self.score_vars[idx].get().strip())
        except Exception:
            self.state.log("Очки: нужно целое число.")
            return
        self.state.set_score(idx, val)
        self.game_window.refresh_from_state()
        self._refresh_scores_panel()

    def on_next_trio(self) -> None:
        self.state.next_trio()
        self._refresh_scores_panel()
        self._refresh_history_panel()
        self.game_window.refresh_from_state()

    # -------------------- UI refresh --------------------
    def _refresh_puzzles_list(self) -> None:
        self.puzzles_list.delete(0, "end")
        for i, p in enumerate(self.state.puzzles):
            self.puzzles_list.insert("end", f"{i + 1}. [{p.category}] {p.question} → {p.answer}")
        if self.state.current_puzzle_idx is not None and self.state.puzzles:
            self.puzzles_list.selection_clear(0, "end")
            self.puzzles_list.selection_set(self.state.current_puzzle_idx)
            self.puzzles_list.see(self.state.current_puzzle_idx)

    def _refresh_scores_panel(self) -> None:
        for i, pl in enumerate(self.state.current_trio.players[:3]):
            self.name_vars[i].set(pl.name)
            self.score_vars[i].set(str(pl.score))

    def _refresh_history_panel(self) -> None:
        self.hist_text.configure(state="normal")
        self.hist_text.delete("1.0", "end")
        for t in self.state.trios_history:
            self.hist_text.insert("end", f"{t.label}\n")
            for p in t.players:
                self.hist_text.insert("end", f"  {p.name}: {p.score}\n")
            self.hist_text.insert("end", "\n")
        self.hist_text.insert("end", f"Текущая: {self.state.current_trio.label}\n")
        self.hist_text.configure(state="disabled")

    # -------------------- log terminal --------------------
    def _toggle_log(self) -> None:
        if self._log_visible.get():
            self.log_text.pack(fill="both", expand=True, padx=10, pady=10)
        else:
            self.log_text.pack_forget()

    def _clear_log(self) -> None:
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", "end")
        self.log_text.insert("end", "[CLEAR]\n")
        self.log_text.configure(state="disabled")
        self.state.clear_log()

    def _on_log(self, ev) -> None:
        # keep terminal-like formatting
        line = f"[{ev.ts.strftime('%H:%M:%S')}] {ev.text}\n"
        self.log_text.configure(state="normal")
        self.log_text.insert("end", line)
        self.log_text.see("end")
        self.log_text.configure(state="disabled")


def _row(parent: tk.Widget, r: int, label: str, var: tk.StringVar) -> None:
    ttk.Label(parent, text=label).grid(row=r, column=0, sticky="w", pady=4)
    ttk.Entry(parent, textvariable=var, width=60).grid(row=r, column=1, sticky="we", pady=4)
    parent.grid_columnconfigure(1, weight=1)

